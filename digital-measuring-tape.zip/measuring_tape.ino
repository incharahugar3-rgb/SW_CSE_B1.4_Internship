/*
  DIGITAL MEASURING TAPE
  Hardware:
  - Arduino UNO
  - HC-SR04 ultrasonic sensor
  - 16x2 I2C LCD
  - Optional push button for HOLD/RESET

  Wiring:
  HC-SR04: VCC -> 5V, GND -> GND, TRIG -> D9, ECHO -> D10
  I2C LCD: VCC -> 5V, GND -> GND, SDA -> A4, SCL -> A5
*/

#include <Wire.h>
#include <LiquidCrystal_I2C.h>

LiquidCrystal_I2C lcd(0x27, 16, 2);

const int trigPin = 9;
const int echoPin = 10;

float readDistanceCm() {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(3);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  long duration = pulseIn(echoPin, HIGH, 30000);
  if (duration == 0) return -1;

  return duration * 0.0343 / 2.0;
}

void setup() {
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);

  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("Digital Measure");
  lcd.setCursor(0, 1);
  lcd.print("Starting...");
  delay(1500);
  lcd.clear();
}

void loop() {
  float distance = readDistanceCm();

  lcd.clear();
  if (distance < 0 || distance > 400) {
    lcd.setCursor(0, 0);
    lcd.print("Out of range");
  } else {
    lcd.setCursor(0, 0);
    lcd.print("Distance:");
    lcd.setCursor(0, 1);
    lcd.print(distance, 1);
    lcd.print(" cm");
  }

  delay(400);
}
