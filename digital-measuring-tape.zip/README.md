# Digital Measuring Tape

## Project Overview
A contactless digital measuring system built with Arduino UNO and an HC-SR04 ultrasonic sensor. The sensor measures the time taken for an ultrasonic pulse to return after reflecting from an object. Arduino converts that time into distance and displays the result on a 16x2 I2C LCD.

## Features
- Contactless distance measurement
- Real-time LCD output
- Distance displayed in centimeters
- Automatic out-of-range handling
- Simple, low-cost hardware

## Hardware
- Arduino UNO
- HC-SR04 ultrasonic sensor
- 16x2 I2C LCD
- Breadboard and jumper wires
- USB cable / suitable power source

## Software
- Arduino IDE
- Arduino C/C++

## Working
1. Arduino sends a short trigger pulse to the ultrasonic sensor.
2. The sensor emits an ultrasonic wave.
3. The wave reflects from the object and returns to the receiver.
4. Arduino measures the echo duration.
5. Distance is calculated using the speed of sound.
6. The calculated distance is shown on the LCD.

Formula:

Distance = (Echo time × speed of sound) / 2

The division by 2 accounts for the outgoing and returning paths.

## Pin Connections

| Component | Arduino |
|---|---|
| HC-SR04 VCC | 5V |
| HC-SR04 GND | GND |
| HC-SR04 TRIG | D9 |
| HC-SR04 ECHO | D10 |
| LCD VCC | 5V |
| LCD GND | GND |
| LCD SDA | A4 |
| LCD SCL | A5 |

## Future Improvements
- Add a hold/reset button
- Add selectable cm/inch modes
- Store recent measurements
- Add rechargeable battery power
- Add a larger graphical display

## Portfolio Description
**Digital Measuring Tape — Arduino, C/C++, HC-SR04, I2C LCD**  
Designed and programmed a contactless distance measurement system using ultrasonic sensing and Arduino, with real-time measurement output on an LCD.
