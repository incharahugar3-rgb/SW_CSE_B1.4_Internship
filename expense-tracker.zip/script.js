const KEY="expenseflow.transactions.v1";
let transactions=JSON.parse(localStorage.getItem(KEY)||"[]");
const $=id=>document.getElementById(id);
function save(){localStorage.setItem(KEY,JSON.stringify(transactions))}
function money(n){return new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",maximumFractionDigits:2}).format(n)}
function render(){
  const q=$("search").value.toLowerCase();
  const filtered=transactions.filter(t=>(t.description+" "+t.category).toLowerCase().includes(q));
  const inc=transactions.filter(t=>t.type==="income").reduce((s,t)=>s+t.amount,0);
  const exp=transactions.filter(t=>t.type==="expense").reduce((s,t)=>s+t.amount,0);
  $("income").textContent=money(inc);$("expense").textContent=money(exp);$("balance").textContent=money(inc-exp);
  $("empty").style.display=filtered.length?"none":"block";
  $("list").innerHTML=filtered.map(t=>`<div class="item">
    <div class="item-left"><div class="icon">${t.type==="income"?"↑":"↓"}</div><div><b>${escapeHtml(t.description)}</b><small>${escapeHtml(t.category)} · ${t.date}</small></div></div>
    <div><span class="amount ${t.type}">${t.type==="income"?"+":"−"}${money(t.amount)}</span><button class="delete" data-id="${t.id}" title="Delete">×</button></div>
  </div>`).join("");
  document.querySelectorAll(".delete").forEach(b=>b.onclick=()=>{transactions=transactions.filter(t=>t.id!==b.dataset.id);save();render()});
}
function escapeHtml(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
$("form").onsubmit=e=>{
 e.preventDefault();
 const amount=Number($("amount").value);
 if(!amount||amount<=0)return;
 transactions.unshift({id:crypto.randomUUID(),description:$("description").value.trim(),amount,type:$("type").value,category:$("category").value,date:new Date().toLocaleDateString("en-IN",{day:"2-digit",month:"short",year:"numeric"})});
 save();e.target.reset();render();
};
$("search").oninput=render;
$("clearAll").onclick=()=>{if(transactions.length&&confirm("Delete all transactions?")){transactions=[];save();render()}};
render();